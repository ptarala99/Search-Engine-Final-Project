#ifndef TEAMMEMBER_H
#define TEAMMEMBER_H


class Teammember
{
public:
    Teammember();
};

#endif // TEAMMEMBER_H
