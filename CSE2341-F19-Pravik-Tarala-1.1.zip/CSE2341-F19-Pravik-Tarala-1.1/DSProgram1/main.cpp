#include <iostream>
#include "dsstring.h"
using namespace std;

int main()
{
    DSString f = "helpp";
    DSString s = "Hello";
    DSString e = "SMU";
    DSString y = "Hello";
    DSString a = "";
    //e = s;
    //cout << s;
    //cout << e;
    //DSString x = s + e;
    DSString x = y.substring(3,2);
    DSString z = y.substring(3,-2);
    //cout << x;
   // cout << z;
    //DSString x = s + e;
    //cout << x;
    //cout << s.size();
    char d;
    d = s[1];
    DSString word = "Hello I am there";
    char* cstring;
    cstring = word.c_str(word);
    //cout << cstring;
    bool b;
    b = (s==y);
    //cout << b;
    bool c;
    c = (f == s);
    cout << c << endl;

    //cout << d;
    //bool smth = s == "Hello";
    //cout << smth;
    system("pause");
    return 0;

}
