#include "teammember.h"
#include "dsstring.h"

Teammember::Teammember()
{
    DSString name = "";
    int idNum = 0;
}
