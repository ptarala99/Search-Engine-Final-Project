#include "team.h"
#include "dsstring.h"
#include <iostream>
#include <fstream>
#include <sstream>
using namespace std;
/*
 * Default constructor for teammember
 * set all members to default values*/
Team::Team(){
    name = "";
    numMems = 0;
    members = nullptr;

}

/*
 * Constructor for teammember
 * set all values to user selections
 */
Team::Team(DSString myname,int mynumMems){
     name = myname;
     numMems = mynumMems;
     members = nullptr;
}

//Destructor for team class
Team::~Team(){
    delete [] members;
}


//return name of the Team
DSString Team :: getName(){
    return  this -> name;
}

//setter for Teams name
void Team :: setName(DSString myName){
    name = myName;
}

//return the number of members on the team
int Team :: getNumMembers(){
    return this -> numMems;
}

//set the number of members on the team
void Team :: setNumMembers(int myNumMembers){
    numMems = myNumMembers;
}
/*
 * return member at a specific index
 */
Teammember* Team :: getTeamMember(int num){
    return  members[num];
}

//calculate total number of points for a team
//loop through array of members and get number
//of points for each and add them to num points
//return numpoints
int Team :: getTotalPoints(){
    int numpoints = 0;
    for(int i = 0; i < numMems; i++){
        numpoints += members[i]->getNumPoints();
    }
    return numpoints;
}

/*
 * allocate space for team member objects
 * set all objects in array to default value team members
 */
void Team :: setTeamMember(char* argv[],int i){
    char* teamname = new char [30];
    int numMembers;
    ifstream inFS;
    inFS.open(argv[i]);
    /*if(inFS.is_open()){
        cout << "success";
    }
    else{
        cout << "error";
    }*/
    inFS.getline(teamname,30);
    setName(teamname);
    inFS >> numMembers;
    setNumMembers(numMembers);
    int IDNum;
    char* playername = new char[20];

    members =new Teammember*[numMembers];

    for(int i =0; i < numMembers; i++){
      inFS >> IDNum;
      inFS >> playername;
      members[i] = new Teammember();
      members[i]->setName(playername);
      members[i]->setIDNumber(IDNum);
    }
    //delete [] members;
    delete [] teamname;
    delete [] playername;
    inFS.close();
}

/*
 * Get the most number of points scored by a player
 * In a team. set initial max to the first element
 * then go through end of array and find member with most
 * points and return the number of points*/
int Team:: getTopPoints(){
    int temp =members[0]->getNumPoints();
    for(int i =0; i < numMems; i++){
        if(members[i]->getNumPoints() > temp){
            temp = members[i]->getNumPoints();
        }
    }
    return temp;

}

/* return the name of the player who
 * scored the most points on the team
 * find the index of the player who scored the most
 * points and then get the name of player at that
 * index*/
DSString Team:: getTopScorer(){
    DSString temporary;
    int highscore = members[0]->getNumPoints();
    for(int i = 0; i < numMems; i++){
         if(members[i]->getNumPoints() > highscore){
             highscore = members[i]->getNumPoints();
             temporary = members[i]->getName();
         }
    }
    return temporary;
}


void Team:: sortByNumTags(){
    Teammember* temp;
    for(int i = 0; i < numMems; i++){
        for(int j = 0; j < numMems - 1; i++){
            if(members[j]->getNumTags() > members[j + 1]->getNumTags()){
                temp = members[j];
                members[j] = members[j + 1];
                members[j + 1] = temp;
            }
        }
    }
}






