#include "teammember.h"
#include "dsstring.h"
/*
 * Default constructor
 * for Teamembers class*/
Teammember::Teammember(){
    name = "";
    IDNumber = 0;
    numTags = 0;
    numPoints = 0;
}

/*
 * Constructor to set
 * attributes of teammembers
 */
Teammember::Teammember(DSString somename, int someID, int someTags, int someNumPoints){
    name = somename;
    IDNumber = someID;
    numTags = someTags;
    numPoints = someNumPoints;
}

/*
 * Copy constructor for Teammembers
 * used to copy teammembers
 */
Teammember::Teammember(const Teammember& member){
    name = member.name;
    IDNumber = member.IDNumber;
    numTags = member.numTags;
    numPoints = member.numPoints;
}

/*
 * assigment operator for Teammember
 * used to assign attributes and return
 * object*/
Teammember& Teammember::operator=(const Teammember& member){
    name = member.name;
    IDNumber = member.IDNumber;
    numTags = member.numTags;
    numPoints = member.numPoints;
    return *this;
}

//return name of Teammember
DSString Teammember:: getName(){
    return this -> name;
}

//set the name of teammember
void Teammember:: setName(DSString myname){
    name = myname;
}

//return ID of TeamMember
int Teammember:: getIDNumber(){
    return this -> IDNumber;
}

//set ID of Teammember
void Teammember:: setIDNumber(int myIDNumber){
    IDNumber = myIDNumber;
}

//return the number of tags of teammember
int Teammember:: getNumTags(){
    return this -> numTags;
}

//set the number of tags of the teammember
void Teammember:: setNumTags(int myNumTags){
    numTags = myNumTags;
}

//increment number of tags of teammember
void Teammember::incNumTags(){
    numTags++;
}

//return the number of points of the teammember
int Teammember::getNumPoints(){
    return this -> numPoints;
}

//set number of points a team member has
void Teammember::setNumPoints(int myNumPoints){
    numPoints = myNumPoints;
}

//add points to a teammember
void Teammember :: addPoints(int pointsToAdd){
     numPoints += pointsToAdd;
}






