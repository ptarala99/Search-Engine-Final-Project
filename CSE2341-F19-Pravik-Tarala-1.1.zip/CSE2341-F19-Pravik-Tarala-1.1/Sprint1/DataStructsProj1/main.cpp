﻿#include <iostream>
#include "dsstring.h"
#include <sstream>
#include<fstream>
#include"team.h"
#include"teammember.h"
using namespace std;

int main(int argc, char* argv[])
{
    //create team pointers
    Team* team1 = new Team();
    Team* team2 = new Team();
    //allocate space for team members
    team1->setTeamMember(argv,1);
    team2->setTeamMember(argv,2);
    //get number of members for team 1
    int num = team1->getNumMembers();
    for (int i = 0; i<num; i++) {
        Teammember* member = team1->getTeamMember(i);
        DSString n = member->getName();
        cout << n ;
        cout << " " ;
        int id = member->getIDNumber();
        cout << id << endl;
    }
    //get number of members for team 2
    int num2 = team2->getNumMembers();
    for(int i =0; i < num2; i++){
        Teammember* member2 = team2->getTeamMember(i);
        DSString n = member2->getName();
        cout << n;
        cout << " ";
        int id = member2->getIDNumber();
        cout << id << endl;
    }

    ifstream inFS;
    inFS.open(argv[3]);
    //get The number of tags that happened
    int numTags;
    inFS >> numTags;
    for(int i =0; i < numTags; i++){
        //get all input file data
        int taggerID;
        inFS >> taggerID;
        int targetID;
        inFS >> targetID;
        int numSecs;
        inFS >> numSecs;
        int pointID;
        inFS >> pointID;
        //go through team1 to check for a match in taggerID and if there is increment number of tags by 1
        //add points to that member based on location they tagged
        //set j = 0 and break if match found so we can search for the next member by going through all elements.
        for(int j =0; j < num; j++){
            Teammember* member1 = team1->getTeamMember(j);
            if(member1->getIDNumber() == taggerID){

                 member1->incNumTags();
                  if(pointID == 1){
                      member1->addPoints(5);
                      j = 0;
                      break;
                  }
                  else if(pointID == 2){
                      member1->addPoints(8);
                      j = 0;
                      break;
                  }
                  else if(pointID == 3){
                      member1->addPoints(7);
                      j = 0;
                      break;
                  }
                  else if(pointID == 4){
                      member1->addPoints(4);
                      j = 0;
                      break;
                  }

            }
        }
        //go through team2 to check for match in taggerID and if there is increment number of tags by 1
        //add points to that member based on location tagged
        //set k = 0 and break if found so we can search for the next member by going through all elements
        for(int k = 0; k < num2; k++){
            Teammember* member2 = team2->getTeamMember(k);
            if(member2->getIDNumber() == taggerID){
                  member2->incNumTags();
                  if(pointID == 1){
                       member2->addPoints(5);
                       k = 0;
                       break;
                  }
                  else if(pointID == 2){
                      member2->addPoints(8);
                      k = 0;
                      break;
                  }
                  else if(pointID == 3){
                      member2->addPoints(7);
                      k = 0;
                      break;
                  }
                  else if(pointID == 4){
                      member2->addPoints(4);
                      k = 0;
                      break;
                  }

            }
        }
    }
    inFS.close();


    //if low verbosity is selected output team names and total points
    //In addition to overall winner
    ofstream outfile(argv[4]);
    if(strcmp(argv[5],"vlow") == 0){
    outfile << team1->getName() << ": " << team1->getTotalPoints()<< " Points" << endl;
    outfile << team2->getName() << ": " << team2->getTotalPoints()<< " Points" << endl;

    if( team1 ->getTotalPoints() > team2 ->getTotalPoints()){
        outfile << "Overall Winners: "  << team1->getName() << endl;
    }
    else if(team2 ->getTotalPoints() > team1 ->getTotalPoints()){
        outfile << "Overall Winners: "  << team2->getName() << endl;
    }
    else{
        outfile << "We have a tie" << endl;
    }
   }

    //if medium verbosity is selected output teamnames
    //output number of tags for each player
    //also output highest scorer for each team
    //In addition to to the overall winner
    else if(strcmp(argv[5],"vmed") == 0){
        outfile << team1->getName()<< endl;
        for(int i = 0; i < team1->getNumMembers(); i++){
            outfile << "    " << team1->getTeamMember(i)->getName() << " had a total of " << team1->getTeamMember(i)->getNumTags() << " tags" << endl;
        }
        outfile << endl;
        outfile << team2->getName() << endl;
        for(int j = 0; j < team2->getNumMembers();j++){
             outfile << "    " << team2->getTeamMember(j)->getName() << " had a total of " << team2->getTeamMember(j)->getNumTags() << " tags" << endl;
        }
        outfile << endl;
        outfile << endl;
        outfile << "Best score from " << team1->getName() << ": " << team1->getTopScorer() << "(" << team1->getTopPoints() << " points" << ")" << endl;
        outfile << "Best score from " << team2->getName() << ": " << team2->getTopScorer() << "(" << team2->getTopPoints() << " points" << ")" << endl;
        outfile << team1->getName() << ": " << team1->getTotalPoints()<< " Points" << endl;
        outfile << team2->getName() << ": " << team2->getTotalPoints()<< " Points" << endl;
        if( team1 ->getTotalPoints() > team2 ->getTotalPoints()){
            outfile << "Overall Winners: "  << team1->getName() << endl;
        }
        else if(team2 ->getTotalPoints() > team1 ->getTotalPoints()){
            outfile << "Overall Winners: "  << team2->getName() << endl;
        }
        else{
            outfile << "We have a tie" << endl;
        }

    }

     /*
      * If vhigh is selected output number of times
      * each player tagged each other In addition
      * to attributes of vmed and vlow
      */
    else if(strcmp(argv[5],"vhigh") == 0){
        outfile << team1->getName() << endl;
        for(int i = 0; i < num; i++){
            for(int j = 0; j < num2; j++){
                outfile << "  " << team1->getTeamMember(i)->getName() << " tagged " << team2->getTeamMember(j)->getName()  << "   times" << endl;
                if(j == num2 - 1){
                    outfile << "  " <<  team1->getTeamMember(i)->getName() << " had a total of " << team1->getTeamMember(i)->getNumTags() << " tags" << endl;
                }
            }

        }
        outfile << team1->getName() << ":   " << team1->getTotalPoints() << " points" << endl;
        for(int k = 0; k < num2; k++){
            for(int x = 0; x < num; x++){
                outfile << "  " << team2->getTeamMember(k)->getName() << " tagged " << team1->getTeamMember(x)->getName() << "    times" << endl;
                if(x == num - 1){
                    outfile <<"  " << team2->getTeamMember(k)->getName() << " had a total of " << team2->getTeamMember(k)->getNumTags() << " tags" << endl;
                }
            }
        }
        outfile << team2->getName() <<":   " << team2->getTotalPoints() << " points" << endl;

        if( team1 ->getTotalPoints() > team2 ->getTotalPoints()){
            outfile << "Overall Winners: "  << team1->getName() << endl;
        }
        else if(team2 ->getTotalPoints() > team1 ->getTotalPoints()){
            outfile << "Overall Winners: "  << team2->getName() << endl;
        }
        else{
            outfile << "We have a tie" << endl;
        }





    }
    delete team1;
    delete team2;


    system("pause");
    return 0;
}
