#ifndef TEAMMEMBER_H
#define TEAMMEMBER_H
#include "dsstring.h"


class Teammember
{
public:
    Teammember();
    Teammember(DSString somename, int someID, int someTags, int someNumPoints);
    Teammember(const Teammember&);
    Teammember& operator=(const Teammember&);
    DSString getName();
    void setName(DSString myName);
    int getIDNumber();
    void setIDNumber(int myIDNumber);
    void setNumTags(int mynumTags);
    int getNumTags();
    void incNumTags();
    int getNumPoints();
    void setNumPoints(int myNumPoints);
    void addPoints(int pointsToAdd);
private:
    DSString name;
    int IDNumber;
    int numTags;
    int numPoints;

};

#endif // TEAMMEMBER_H
