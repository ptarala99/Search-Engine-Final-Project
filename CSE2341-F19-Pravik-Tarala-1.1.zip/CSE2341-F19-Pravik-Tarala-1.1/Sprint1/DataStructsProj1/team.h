#ifndef TEAM_H
#define TEAM_H
#include "dsstring.h"
#include "teammember.h"

class Team
{
public:
    Team();
    Team(DSString myname,int mynumMems);
    ~Team();
    DSString getName();
    void setName(DSString myName);
    int getNumMembers();
    void setNumMembers(int myNumMembers);
    Teammember* getTeamMember(int num);
    int getTotalPoints();
    void setTeamMember(char* argv[], int i);
    int getTopPoints();
    DSString getTopScorer();
    void sortByNumTags();

private:
     DSString name;
     int numMems;
     Teammember** members;

};

#endif // TEAM_H
