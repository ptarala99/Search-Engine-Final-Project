#include "tag.h"

Tag::Tag()
{
    location = "";
    pointvalue = 0;
    ID = 0;
}

DSString Tag :: getLocation(){
    return location;
}

void Tag :: setLocation(DSString myLocation){
    location = myLocation;
}

int Tag :: getPointValue(){
    return pointvalue;
}

void Tag :: setPointValue( int mypointvalue){
    pointvalue = mypointvalue;
}

int Tag :: getID(){
    return ID;
}

void Tag :: setID(int myID){
    ID = myID;
}
