#ifndef DSSTRING_H
#define DSSTRING_H

#include <iostream>
#include <cstring>

class DSString
{
private:
    char* data;
    int length;
public:
    DSString();
    DSString(const char*);
    DSString(const DSString&);
    ~DSString();

    DSString& operator= (const char*);
    DSString& operator= (const DSString&);
    DSString operator+ (const DSString&);
    DSString& operator+= (const DSString&);
    bool operator== (const char*);
    bool operator== (const DSString&);
    bool operator< (const char*);
    bool operator< (const DSString&);
    char& operator[] (const int);

    int size();

    DSString substring(int a, int b);

    //c_str returns c-string representation of DSString obj.
    char* c_str(DSString data);

    friend std::ostream& operator<<(std::ostream&, const DSString&);
    friend std::istream& operator>>(std::istream&, DSString&);
};

#endif // DSSTRING_H
