#ifndef TAG_H
#define TAG_H
#include  "dsstring.h"

class Tag
{
public:
    Tag();
    DSString getLocation();
    void setLocation(DSString myLocation);
    int getPointValue();
    void setPointValue(int mypointvalue);
    int getID();
    void setID(int myID);



private:
    DSString location;
    int pointvalue;
    int ID;
};

#endif // TAG_H
